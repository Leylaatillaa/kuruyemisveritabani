﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace _12.Hafta
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        SqlConnection kuruyemis = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=KuruyemisProje;Integrated Security=True");
        SqlCommand komut;
        SqlDataReader oku;
        private void veri()
        {
            listView1.Items.Clear();
            kuruyemis.Open();
            komut = new SqlCommand();
            komut.Connection = kuruyemis;
            komut.CommandText = "Select * from Urunler";
            oku = komut.ExecuteReader();
            while(oku.Read())
            {
                ListViewItem ekle = new ListViewItem();
                ekle.Text = oku["Id"].ToString();
                ekle.SubItems.Add(oku["Adi"].ToString());
                ekle.SubItems.Add(oku["Miktar"].ToString());
                ekle.SubItems.Add(oku["Fiyat"].ToString());
                listView1.Items.Add(ekle);
            }
            kuruyemis.Close();
        }


        private void button2_Click(object sender, EventArgs e)
          {
            if ((string.IsNullOrEmpty(textBox2.Text) || (string.IsNullOrEmpty(textBox3.Text) || (string.IsNullOrEmpty(textBox4.Text)))))
            {
                MessageBox.Show("Alanlar Boş Bırakılamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            else
            {
                kuruyemis.Open();
            komut = new SqlCommand("INSERT INTO Urunler (Adi,Miktar,Fiyat) values ('" + textBox2.Text.ToString() + "','" + textBox3.Text.ToString() + "','" + Convert.ToDecimal( textBox4.Text) + "')", kuruyemis);

         
            komut.ExecuteNonQuery();
                kuruyemis.Close();
                veri();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                MessageBox.Show("Kayıt İşlemi Başarılı", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
           }
            
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || (string.IsNullOrEmpty(textBox2.Text) || (string.IsNullOrEmpty(textBox3.Text) || (string.IsNullOrEmpty(textBox4.Text)))))
            {
                MessageBox.Show("Alanlar Boş Bırakılamaz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            else
            {
                kuruyemis.Open();
                komut = new SqlCommand("Update  Urunler Set  Adi=@Adi, Miktar=@Miktar,Fiyat=@Fiyat Where Id=@Id", kuruyemis);
                komut.Parameters.AddWithValue("@Id", textBox1.Text);
                komut.Parameters.AddWithValue("@Adi", textBox2.Text);
                komut.Parameters.AddWithValue("@Miktar", textBox3.Text);
                komut.Parameters.AddWithValue("@Fiyat", Convert.ToDecimal(textBox4.Text));
                komut.ExecuteNonQuery();
                kuruyemis.Close();
                veri();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                MessageBox.Show("Güncelleme İşlemi Başarılı", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            veri();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem sil = listView1.SelectedItems[0];
                string silNo = sil.SubItems[0].Text;
                komut = new SqlCommand("DELETE from Urunler where Id = @Id", kuruyemis);
                komut.Parameters.AddWithValue("@Id", silNo);
                kuruyemis.Open();
                komut.ExecuteNonQuery();
                kuruyemis.Close();
                listView1.Items.Remove(sil);
                MessageBox.Show("Silme İşlemi Başarılı", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else
            {
                MessageBox.Show("Silmek İçin Bir Satır Seçiniz", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

     
        private void Form2_Load(object sender, EventArgs e)
        {
            listView1.FullRowSelect = true;

        }

      
    }
}
