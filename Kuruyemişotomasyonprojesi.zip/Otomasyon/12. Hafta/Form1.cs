﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _12.Hafta
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection kuruyemis = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=KuruyemisProje;Integrated Security=True");
        SqlCommand komut;
        SqlDataReader oku;

        private void button1_Click(object sender, EventArgs e)
        {
            kuruyemis.Open();
            komut = new SqlCommand("INSERT INTO Admin (kadi, sifre, ad, soyad, tel) values ('"+textBox3.Text.ToString()+ "','" + textBox4.Text.ToString()+ "','" + textBox5.Text.ToString() + "','" + textBox6.Text.ToString() + "','" + textBox7.Text.ToString() + "')", kuruyemis);
            komut.ExecuteNonQuery();
            MessageBox.Show("Kayıt Olundu", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            kuruyemis.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string user = textBox1.Text;
            string pass = textBox2.Text;
            komut = new SqlCommand();
            kuruyemis.Open();
            komut.Connection = kuruyemis;
            komut.CommandText = "Select * From Admin where kadi ='"+textBox1.Text+"' And sifre = '"+textBox2.Text+"'";
            oku = komut.ExecuteReader();
            if (oku.Read())
            {
                MessageBox.Show("Giriş Başarılı", "Başarılı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Form2 fr2 = new Form2();
                fr2.Show();
                textBox1.Text = "";
                textBox2.Text = "";
            }
            else
            {
                MessageBox.Show("Giriş Hatalı", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            kuruyemis.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
